<?
include("functions.php");
get_account_img("229055253722");
?>